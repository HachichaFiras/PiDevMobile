/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.utils;

/**
 *
 * @author 21624
 */
public class statics {
    public static final String Base_URL="http://127.0.0.1:8000/";
    
}
